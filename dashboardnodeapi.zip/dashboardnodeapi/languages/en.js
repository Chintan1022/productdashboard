var messages = {

	// validator messages
	"accepted": "The :attr must be accepted",
	"email": "The :attr must be a valid email address",
	"exists": "The selected :attr is invalid",
	"in": "The selected :attr is invalid",
	"integer": "The :attr must be an integer",
	"required": "The :attr field is required",
	"required_if": "The :attr field is required when :other is :value",
	"required_unless": "The :attr field is required unless :other is in :values",

	// Push Notification
	"followed":"{username} is now following you",
	
	// Messages
	"text_admin_invalid_api_key": "Invalid API key",
	"text_admin_api_no_data": "No data found",
	"text_admin_tokeninvalid": "Invalid token provided.",
	"text_admin_something_wrong":"Something Wrong",
	"text_admin_invalid_login_details": "Please enter valid login credentials.",
	"text_admin_duplicate_email": "There is already an account registered with this email address",
	"text_admin_login_success": "Login successfully",
	"text_admin_logout_success": "Logout successfully",
    "text_admin_does_not_exist": "No data found",
	"text_admin_oldpassword_incorrect":"old password is incorrect",
	"text_admin_newold_password_similar":"new Password and Old password is similar",
	"text_admin_password_change_fail":"change password failed",
	"text_admin_password_change_success":"password change succesfully",
	"text_admin_details_does_not_exist":"Admin Details Does not exist",
	"text_admin_get_dashboard_details_success":"Get Deshboard Details Successfully",
	"text_admin_get_dashboard_details_fail":"Get Deshboard Details fail",
	"text_admin_delete_user_success":"Delete UserDetails Successfully",
	"text_admin_delete_user_fail":"Delete UserDetails fail",
	"text_admin_get_user_success":"get user successfully",
	"text_admin_get_user_fail":"get user fail",
	"text_admin_update_user_details_success":"update user details successfully",
	"text_admin_update_user_details_fail":"update user details fail",
	"text_admin_user_add_product_success":"Add Product Successfully",
	"text_admin_user_add_product_fail":"Add Product fail",
	"text_admin_delete_product_success":"Delete Product successfully",
	"text_admin_delete_product_fail":"Delete Product fail",
	"text_admin_get_single_product_success":"Get Product successfully",
	"text_admin_get_single_product_fail":"Get Product fail",
	"text_admin_update_product_details_success":"Update Product Details Successfully",
	"text_admin_update_product_details_fail":"Update Product Details fail",
	"text_admin_get_profile_success":"get profile details successfully",
	"text_admin_get_profile_fail":"get profile details fail",
	"text_admin_get_users_details_success":"get users detail successfully",
	"text_admin_get_users_details_fail":"get users detail fail",
	"text_admin_get_product_details_success":"get Products Detail Successfully",
	"text_admin_get_product_details_fail":"get Products Detail fail"












};
module.exports = messages;