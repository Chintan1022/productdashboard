var con = require('./database');

var Validate={

    //Function to generate the random hash for token
    generateSessionCode: function (request,callback) {
        
        var randtoken = require('rand-token').generator();
        var usersession = randtoken.generate(64, "0123456789abcdefghijklnmopqrstuvwxyz");
        
        Validate.checkDeviceInfo(request, function (DeviceInfo) {
            console.log(DeviceInfo)
            if (DeviceInfo != null) {
                var params = {
                    token: usersession
                };
                Validate.updateDeviceInfo(request,params, function () {
                    console.log(usersession)
                    callback(usersession);
                });
            } else {
                var params = {
                    token: usersession,
                    user_id: request.user_id,
                };
                Validate.addDeviceInformation(params, function () {
                    callback(usersession);
                });
            }
        });
    },


    //Function to check device information of any users
     checkDeviceInfo: function (request, callback) {
       var sql ="SELECT * FROM tbl_user_token WHERE user_id = '" + request.user_id + "' "
        con.query(sql, function (err, result) {

            if (!err && result != undefined) {
                callback(result[0]);
            } else {
                callback(null,err);
            }
        });
    },
 

    //Function to check and update device information
    checkUpdateDeviceInfo: function (request, callback) {
        var upd_device = {
            token:(request.token != undefined) ? request.token : ""
            /* token:(request.token != undefined) ? request.token : "",
            uuid: (request.uuid != undefined) ? request.uuid : "",
            ip: (request.ip != undefined) ? request.ip : "",
            os_version: (request.os_version != undefined) ? request.os_version : "",
            model_name: (request.model_name != undefined) ? request.model_name : "",
            device_name:request.device_name,
            device_type: request.device_type,
            device_token: request.device_token, */
        };

       Validate.checkDeviceInfo(request, function (DeviceInfo) {
            if (DeviceInfo != undefined) {
                Validate.updateDeviceInfo(request, upd_device, function (result) {
                    callback(result);
                });
            } else {
                upd_device.user_id = request.user_id;
                Validate.addDeviceInformation(upd_device, function (result) {
                    callback(result);
                });
            }
        });
    },


    //Function to update device information of any users
    updateDeviceInfo: function (request, params, callback) {
        con.query("UPDATE tbl_user_token SET ? WHERE user_id = '" + request.user_id + "'  ", params, function (err,result) {
            console.log("abcd",result)
            callback(result);
        });
    },


    //Add Device Information for users
    addDeviceInformation: function (user, callback) {
     con.query('INSERT INTO tbl_user_token SET ?',user, function (err, result,fields) {
     callback(result);
    });
    },

   
}
module.exports = Validate;
