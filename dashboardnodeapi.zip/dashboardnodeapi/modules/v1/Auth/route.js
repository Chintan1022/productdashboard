var express = require('express');
var middleware = require('../../../middleware/headerValidator');
var auth_model = require('./auth_model');
const { request } = require('express');
var router = express.Router();


//api for login
router.post("/login", function (req, res) {

    var rules = {           
        email:'required',
        password: 'required',           
    }
    const messages = {
        'required': req.language.required,
        'in': req.language.in,
    }
    
 var request = req.body
 
    // checks all validation rules defined above and if error send back response
    if (middleware.checkValidationRules(request, res, rules, messages, {})) {
        auth_model.checkLogin(request, function (responsecode, responsemsg, responsedata) {
            middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata);
        });
    }
});

//api for logout
router.get("/logout", function (req, res) {
    request.user_id = req.user_id
        auth_model.logout(request, function (responsecode, responsemsg, responsedata) {
        middleware.sendresponse(req, res, 200, responsecode, responsemsg,responsedata);
    });
});

//api for dashboard card user count
router.get("/dashboard", function (req, res) {
    auth_model.dashboard(req, function (responsecode, responsemsg, responsedata) {
        middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata);
    });
});

//api for change password
router.post("/changePassword", function (req, res) {
        var rules = {
            oldPwd: 'required',
            newPwd: 'required',
        }

        const messages = {
            'required': req.language.required
        }
        var request = req.body
        request.user_id=req.user_id
        if (middleware.checkValidationRules(request, res, rules, messages, {})) {
            auth_model.changePassword(request, function (responsecode, responsemsg, responsedata) {
                middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata);
            });
        }
 
});

//api for add user
router.post("/addUser", function (req, res) {
    var rules = {
        name:'required',
        email: 'required|email',
        password: 'required',  
        phoneno:'required',
        role:'required',
        country:'required',
        
    }
    
    const messages = {
        'required': req.language.required,
        'in': req.language.in,
    }
   
    var request = req.body
  
    if (middleware.checkValidationRules(request, res, rules, messages, {})) {
        auth_model.addUser(request, function (responsecode, responsemsg, responsedata) {
        middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata);
        });
    }
});

//api for get user details
router.post("/getSingleUser", function (req, res) {

    var rules = {
        id: 'required',
       
    }
     
    const messages = {
        'required': req.language.required,
    }
    var request = req.body
    if (middleware.checkValidationRules(request, res, rules, messages, {})) {
        auth_model.getSingleUser(request, function (responsecode, responsemsg, responsedata) {
            middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata);
        });
    }
});

//api for update userdetails
router.post("/updateUserDetails", function (req, res) {
    var rules = {
        id: 'required',
        name:'required',
        email: 'required|email',
        phoneno:'required',
    }
    const messages = {
        'required': req.language.required
    }

    var request = req.body;
   
    if (middleware.checkValidationRules(request, res, rules, messages, {})) {
         auth_model.updateUserDetail(request, function (responsecode, responsemsg, responsedata) {
            middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata);
        });
    }
});

//api for delete user
router.post("/deleteUser", function (req, res) {

    var rules = {
        getid: 'required',
       
    }
     
    const messages = {
        'required': req.language.required,
    }
    var request = req.body
    
    // checks all validation rules defined above and if error send back response
    if (middleware.checkValidationRules(request, res, rules, messages, {})) {
        auth_model.deleteUser(request, function (responsecode, responsemsg, responsedata) {
            middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata);
        });
    }

});


//api for add product
router.post("/addProduct", function (req, res) {
   
   
    var rules = {
        product_name:'required',
        product_price:'required',
        about:'required',
    }
    
    const messages = {
        'required': req.language.required,
        'in': req.language.in,
    }
   
    var request = req.body
  
    if (middleware.checkValidationRules(request, res, rules, messages, {})) {
        auth_model.addProduct(request, function (responsecode, responsemsg, responsedata) {
        middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata);
        });
    }
});


//api for delete product
router.post("/deleteProduct", function (req, res) {

    var rules = {
        getid: 'required',
       
    }
     
    const messages = {
        'required': req.language.required,
    }
    var request = req.body
    
   if (middleware.checkValidationRules(request, res, rules, messages, {})) {
        auth_model.deleteProduct(request, function (responsecode, responsemsg, responsedata) {
            middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata);
        });
    }

});

//api for get product details
router.post("/getSingleProduct", function (req, res) {

    var rules = {
        id: 'required',
       
    }
     
    const messages = {
        'required': req.language.required,
    }
    var request = req.body
   
    if (middleware.checkValidationRules(request, res, rules, messages, {})) {
        auth_model.getSingleProduct(request, function (responsecode, responsemsg, responsedata) {
            middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata);
        });
    }

});

//api for update productdetails
router.post("/updateProductDetails", function (req, res) {
    
    var rules = {
        id: 'required',
        product_name:'required',
        product_price:'required',
        about:'required'
    }
    const messages = {
        'required': req.language.required
    }

    var request = req.body;
    if (middleware.checkValidationRules(request, res, rules, messages, {})) {
         auth_model.updateProductDetail(request, function (responsecode, responsemsg, responsedata) {
            middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata);
        });
    }
});

//api for get profile details
router.get("/getuserprofile", function (req, res) {
    auth_model.userprofile(req, function (responsecode, responsemsg, responsedata) {
        middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata);
    });
});

//api for get userdetails
router.get("/userDetails", function (req, res) {
    auth_model.getUserDetails(req, function (responsecode, responsemsg, responsedata) {
        middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata);
    });
});

//api for get products details
router.get("/getProductDetails", function (req, res) {
    auth_model.getProductsDetails(req, function (responsecode, responsemsg, responsedata) {
        middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata);
    });
});
       
module.exports = router; 