var con = require("../../../config/database");
var common = require("../../../config/common");
var Auth = {
 
  //function for check login details
  checkLogin: function (request, callback) {
    con.query("SELECT * FROM tbl_user where  email= '" + request.email + "' AND is_deleted='0' AND is_active='1' AND role='admin' ",function (err, result) {
        if (!err && result[0] != undefined) {
          if (result[0].password === request.password) {
            var updparams = {
              is_online: "1",
              last_login: require("node-datetime").create().format("Y-m-d H:M:S"),
            };
            request.user_id = result[0].id;
            common.checkUpdateDeviceInfo(request, function () {
              Auth.updateuser(request,updparams,function (userprofile, error) {
                  common.generateSessionCode(request, function (Token) {
                    userprofile.token = Token;
                    callback("1", { keyword: "text_admin_login_success", components: {} },userprofile);
                  });
                }
              );
            });
          } 
          else {
            callback("0",{ keyword: "text_admin_invalid_login_details", components: {} }, null);
          }
        }
      }
    );
  },

   //function for logout
  logout: function (request, callback) {
  
    var updusers = {
      is_online: "0",
    };
    Auth.updateuser(request, updusers, function (userprofile) {
      
      
      if (userprofile != null) {
        var deviceparam = {
          token: "",
        };
        common.updateDeviceInfo(request, deviceparam, function () {
          callback("1",{ keyword: "text_admin_logout_success", components: {} },null);
        });
      } 
      else {
        callback("0",{ keyword: "text_admin_something_went_wrong", components: {} },null);
      }
    });
  },

  //funtion for get dashboard details
  dashboard: function (req, callback) {
      con.query("SELECT COUNT(name)as usercount FROM tbl_user", function (err, result, fields) {
        if (!err && result[0]!=undefined) {
            callback('1', { keyword: 'text_admin_get_dashboard_details_success'}, result[0]);   

        } else {
            callback('0', { keyword: 'text_admin_get_dashboard_details_fail'}, null);   

        }
    });
  }, 

  //function for getuserdetails
  userdetails: function (request, callback) {
  var sql = "SELECT u.*,IFNULL(ut.token,'') as token FROM tbl_user u LEFT JOIN tbl_user_token as ut ON u.id = ut.user_id WHERE u.id = '" + request.user_id + "' AND u.is_active='1' AND u.is_deleted='0' GROUP BY u.id order by u.id desc"
   con.query(sql, function (err, result) {
       if (!err && result != undefined) {
         callback(result[0]);
       } else {
         callback(null);
       }
     }
   );
  }, 

  //function for update user details
  updateuser: function (request, upd_params, callback) {
    con.query("UPDATE tbl_user SET ? WHERE id = ? ",[upd_params, request.user_id],function (err,result) {
       if (!err) {
          Auth.userdetails(request, function (response) {
            callback(response);
          });
        } else {
          callback(null, err);
        }
      }
    );
  },

  //function for changepassword
  changePassword: function (request, callback) {
    Auth.userdetails(request, function (userprofile) {
      console.log(userprofile)
      var currentpassword = userprofile.password;
      if (userprofile != null) {
        if (currentpassword != request.oldPwd) {
          callback("0",{keyword: "text_admin_oldpassword_incorrect",components: {},},null);
        } else if (currentpassword == request.newPwd) {
          callback("0",{keyword: "text_admin_newold_password_similar",components: {},},null);
        } else {
          var password = request.newPwd
          var updparams = {
            password: password,
          };
          Auth.updateuser(request, updparams, function (userprofile) {
            if (userprofile == null) {
              callback("0",{keyword: "text_admin_password_change_fail", components: {}}, null);
            } 
            else {
              callback("1", {keyword: "text_admin_password_change_success",components: {}},userprofile);
            }
          });
        }
      }
      else {
        callback("0",{ keyword: "text_admin_details_does_not_exist",components: {},}, null);
      }
    });
  },

  //function for add user 
  addUser: function (request, callback) {
    Auth.checkUniqueEmail(request, function (uniquecode, uniquemsg, isUnique) {

        if (isUnique) {
            var user = {
                name:request.name,
                email: request.email,
                phoneno:request.phoneno,
                password: request.password,
                role:request.role,
                country:request.country,
                is_online: "1",
                is_active: "1",
                is_deleted: "0",
            };
            con.query('INSERT INTO tbl_user SET ?', user, function (err, result) {
              
                if (!err && result !=undefined) {
                  request.user_id = result.insertId;
                  common.checkUpdateDeviceInfo(request,function () {
                        Auth.userdetails(request, function (userprofile) {
                            common.generateSessionCode(request, function (Token) {  
                                userprofile.token = Token;                             
                                callback('1', {keyword: 'text_admin_user_add_success',components: {}}, userprofile);
                            });
                        });
                      })
                } else {
                    callback('0', {keyword: 'text_admin_user_add_fail',components: {}}, null);
                }
            });

        } else {
            callback(uniquecode, uniquemsg, null);
        }
    });
  },

  //function for check unique email
  checkUniqueEmail: function (request, callback) {

    if (request.email != undefined && request.email != '') {
  
       var uniqueEmail = "SELECT * FROM tbl_user WHERE email = '" + request.email + "' AND is_deleted='0' ";
        
        con.query(uniqueEmail, function (error, result, fields) {
            if (!error && result[0] != undefined) {
                callback('0', { keyword: 'text_admin_duplicate_email',  components: {} }, false);   
            } else {
               
                callback('1', "Success", true);
            }
        });
  
    } else {
        callback('1', "Success", true);
    }
   },

  /* //function for delete user details
  deleteUser: function (request, callback) {
   con.query(`delete from tbl_user where id = ${request.getid}`, function (err, result, fields) {
          if (!err) {
              Auth.deleteToken(request, function (deletetoken, err) {
                  if (deletetoken != null){
                      callback("1", {keyword: "text_admin_delete_user_success",components: {},},deletetoken);
                  }else{
                          callback("0", {keyword: "text_admin_delete_user_fail",components: {},},err); 
                      }
                  });
             
          } else {
              callback('0', {  keyword: 'text_admin_something_wrong',components: {}}, err);
          }
      });
  },

  //function for delete Token
  deleteToken: function (req, callback) {
    con.query("delete from tbl_user_token where user_id = '" + req.getid + "' ", function (err, result) {
         if (!err && result != undefined) {
             callback("1", {keyword: "text_admin_deletetoken_success",components: {},},result); 
         } else {
             callback("0", {keyword: "text_admin_deletetoken_fail",components: {},},err); 
         }
     });
  }, */

  deleteUser: function (request, callback) {
    var updparams={
      is_deleted:"1"
    }
    con.query("UPDATE tbl_user SET ? WHERE id = ? ",[updparams, request.getid],function (err,result) {
       if (!err && result!=undefined) {
        callback("1", {keyword: "text_admin_delete_user_success",components: {},},result);
        } else {
          callback("0", {keyword: "text_admin_delete_user_fail",components: {},},err); 
        }
      }
    );
  },


  //function for getsingleuserdetails
  getSingleUser: function (request, callback) {
  con.query(`select * from tbl_user where id = ${request.id}`, function (err, result, fields) {
      if (!err) {
          callback("1", {keyword: "text_admin_get_user_success",components: {},},result[0]);
      }
      else{
           callback("0", {keyword: "text_admin_get_user_fail",components: {},},err); 
      }
  });
  },

  //function for update user detail
  updateUserDetail: function (request, callback) {

  var updateparams = {
    name:request.name,
    email: request.email,
    phoneno:request.phoneno,
   
                        
  };

  con.query("UPDATE tbl_user SET ? WHERE id = ? ", [updateparams, request.id], function (err, result, fields) {
      if(!err && result!=undefined)
      {
          callback("1", {keyword: "text_admin_update_user_details_success",components: {},},result);
      }
      else
      {
          callback("0", {keyword: "text_admin_update_user_details_fail",components: {},},null);
      }
  });
  },

  //function for add user
  addProduct: function (request, callback) {
  var product = {
    product_name:request.product_name,
    product_price:request.product_price,
    about:request.about,
  };
  con.query('INSERT INTO tbl_product SET ?', product, function (err, result) {
    if (!err && result !=undefined) {
      callback('1', {keyword: 'text_admin_user_add_product_success',components: {}}, product);
    } else {
      callback('0', {keyword: 'text_admin_user_add_product_fail',components: {}}, null);
    }
  });
  },

  //function for delete product details
  deleteProduct: function (request, callback) {
  con.query(`delete from tbl_product where id = ${request.getid}`, function (err, result,f) {
    if (!err && result != undefined) {
      callback("1", {keyword: "text_admin_delete_product_success",components: {},},result);
    }
    else{
      callback("0", {keyword: "text_admin_delete_product_fail",components: {},},err); 
    }
  })
  },

  //function for getsingle productdetails
  getSingleProduct: function (request, callback) {
  con.query(`select * from tbl_product where id = ${request.id}`, function (err, result, fields) {
      if (!err) {
          callback("1", {keyword: "text_admin_get_single_product_success",components: {},},result[0]);
      }
      else{
           callback("0", {keyword: "text_admin_get_single_product_fail",components: {},},err); 
      }
  });
  },

  //function for update product detail
  updateProductDetail: function (request, callback) {
  var updateparams = {
    product_name:request.product_name,
    product_price:request.product_price,
    about:request.about
                        
  };
 con.query("UPDATE tbl_product SET ? WHERE id = ? ", [updateparams, request.id], function (err, result, fields) {
      if(!err && result!=undefined)
      {
          callback("1", {keyword: "text_admin_update_product_details_success",components: {},},updateparams);
      }
      else
      {
          callback("0", {keyword: "text_admin_update_product_details_fail",components: {},},null);
      }
  });
  },

  //function for getadmin profile
  userprofile: function (req, callback) {
 con.query("SELECT u.*,IFNULL(ut.token,'') as token FROM tbl_user u LEFT JOIN tbl_user_token as ut ON u.id = ut.user_id WHERE u.id = '" + req.user_id + "' AND u.is_deleted='0' GROUP BY u.id", function (err, result, fields) {
      if (!err && result[0]!=undefined) {
          callback('1', { keyword: 'text_admin_get_profile_success'}, result[0]);   

      } else {
          callback('0', { keyword: 'text_admin_get_profile_fail'}, null);   

      }
  });
  }, 

  //function for getusersdetails
  getUserDetails:function(request,callback){
  var sql = `select * from tbl_user where is_deleted=0`; 
  con.query(sql,function(err,result){
   if(!err&&result!=undefined)
     {
      callback("1", {keyword: "text_admin_get_users_details_success",components: {},},result);
     }
   else
    {
     callback("0", {keyword: "text_admin_get_users_details_fail",components: {},},null);
    }
  })
  },
 
  //function for getproductsdetails
  getProductsDetails:function(request,callback){
  var sql = `select * from tbl_product where is_active=1`; 
  con.query(sql,function(err,result){
   if(!err&&result!=undefined)
   {
      callback("1", {keyword: "text_admin_get_product_details_success",components: {},},result);
   }
   else
   {
      callback("0", {keyword: "text_admin_get_product_details_fail",components: {},},null);
   }
  })
  },

}
module.exports = Auth;
