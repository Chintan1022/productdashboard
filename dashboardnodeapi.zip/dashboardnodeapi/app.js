var express= require('express');
var app=express();
require("dotenv").config();
const cors = require('cors')

var app = express();
var app_v1 = require('./modules/v1/route_manager');
app.use(cors({origin:"*"}));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use('/api/v1', app_v1);

// Listen to port for app
try {
	server = app.listen(process.env.PORT);
	console.log("Connected to api_dashboard app On PORT : "+process.env.PORT);
} catch (err) {
	console.log("Failed to connect");
}

